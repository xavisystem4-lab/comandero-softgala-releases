/*
  Enlace Móvil 0.2.1 — permisos para ENVIAR COMANDAS a SoftRestaurant.
  Solo hace falta si Enlace Móvil se conecta con el usuario enlace_movil (script 01).
  Si se conecta con su usuario de Windows (botón «Detectar SoftRestaurant»), normalmente ya tiene permisos y no hace falta.

  Reemplace <<BASE_SOFTRESTAURANT>> (normalmente softrestaurant11) y ejecute en SSMS como administrador.
  Tablas: exactamente las que escribe el Comandero de SoftRestaurant al abrir mesa y enviar comanda (traza Fase 0).
*/
USE [<<BASE_SOFTRESTAURANT>>];
GO
GRANT SELECT, INSERT, UPDATE ON dbo.tempcheques     TO enlace_movil;
GRANT SELECT, INSERT         ON dbo.tempcheqdet     TO enlace_movil;
GRANT SELECT, INSERT, UPDATE ON dbo.cuentas         TO enlace_movil;
GRANT SELECT, INSERT         ON dbo.detallescuentas TO enlace_movil;
GRANT SELECT, UPDATE         ON dbo.folios          TO enlace_movil;
GRANT SELECT ON dbo.turnos           TO enlace_movil;
GRANT SELECT ON dbo.tempchequespagos TO enlace_movil;
-- Respaldo COPY_ONLY antes de la primera comanda del día.
ALTER ROLE db_backupoperator ADD MEMBER enlace_movil;
GO
