/*
  Enlace Móvil 0.2.11 — lectura de impresoras de comandas de SoftRestaurant (solo lectura).
  Solo hace falta si Enlace se conecta con el usuario restringido «enlace_movil» (con «sa» no es necesario).
  Ejecutar en la base de SoftRestaurant (ej. softrestaurant11).
*/
GRANT SELECT ON dbo.estaciones      TO enlace_movil;   -- estaciones (PCs) de SR
GRANT SELECT ON dbo.areas           TO enlace_movil;   -- áreas de impresión: BARRA, COCINA…
GRANT SELECT ON dbo.estacionesareas TO enlace_movil;   -- impresora de cada área en cada estación
