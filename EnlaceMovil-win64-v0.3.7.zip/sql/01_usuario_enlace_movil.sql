/*
  Enlace Móvil — usuario SQL de mínimos privilegios.
  Ejecutar UNA vez en SSMS con un usuario administrador, en la PC de SoftRestaurant.

  Antes de ejecutar, reemplace:
    <<CONTRASENA_SEGURA>>   contraseña larga para el usuario enlace_movil
    <<BASE_SOFTRESTAURANT>> nombre real de la base de SoftRestaurant (consulta 1 del anexo de la Fase 0)

  Qué hace:
    - Crea el login enlace_movil (NO usar sa en Enlace Móvil).
    - Crea la base propia "EnlaceMovil" y le da control total SOLO sobre ella.
    - En la base de SoftRestaurant: SOLO SELECT sobre las tablas de catálogo verificadas.
      Ningún permiso de escritura en esta versión.
*/

USE master;
GO
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = 'enlace_movil')
    CREATE LOGIN enlace_movil WITH PASSWORD = '<<CONTRASENA_SEGURA>>', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
GO

IF DB_ID('EnlaceMovil') IS NULL
    CREATE DATABASE EnlaceMovil;
GO
USE EnlaceMovil;
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'enlace_movil')
    CREATE USER enlace_movil FOR LOGIN enlace_movil;
ALTER ROLE db_owner ADD MEMBER enlace_movil;
GO

USE [<<BASE_SOFTRESTAURANT>>];
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'enlace_movil')
    CREATE USER enlace_movil FOR LOGIN enlace_movil;
GO
-- Solo lectura, tabla por tabla (las verificadas en la exportación de catálogo).
GRANT SELECT ON dbo.productos                    TO enlace_movil;
GRANT SELECT ON dbo.productosdetalle             TO enlace_movil;
GRANT SELECT ON dbo.grupos                       TO enlace_movil;
GRANT SELECT ON dbo.subgrupos                    TO enlace_movil;
GRANT SELECT ON dbo.grupossubgrupos              TO enlace_movil;
GRANT SELECT ON dbo.subgruposproductos           TO enlace_movil;
GRANT SELECT ON dbo.gruposmodificadores          TO enlace_movil;
GRANT SELECT ON dbo.gruposmodificadoresproductos TO enlace_movil;
GRANT SELECT ON dbo.modificadores                TO enlace_movil;
GRANT SELECT ON dbo.monitoresproduccion          TO enlace_movil;
-- v0.2.0: meseros (login con su contraseña de SR), mesas abiertas y áreas. Solo lectura.
GRANT SELECT ON dbo.meseros                      TO enlace_movil;
GRANT SELECT ON dbo.tempcheques                  TO enlace_movil;
GRANT SELECT ON dbo.areasrestaurant              TO enlace_movil;
GRANT SELECT ON dbo.empresas                     TO enlace_movil;
GO

/*
  Cadenas de conexión para la pestaña Configuración de Enlace Móvil (ajuste la instancia):
    SoftRestaurant: Server=.\<<INSTANCIA>>;Initial Catalog=<<BASE_SOFTRESTAURANT>>;User Id=enlace_movil;Password=...;TrustServerCertificate=true
    EnlaceMovil:    Server=.\<<INSTANCIA>>;Initial Catalog=EnlaceMovil;User Id=enlace_movil;Password=...;TrustServerCertificate=true

  Si un GRANT falla con "Cannot find the object", esa tabla no existe con ese nombre en su versión:
  NO lo corrija a mano; envíe el mensaje para revisarlo en la Fase 0.
*/
