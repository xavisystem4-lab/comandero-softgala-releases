# Enlace Móvil SoftGala

> Desarrollado por **SoftGala**. Versión 0.2.1.

## Novedades 0.2.5

- **Iniciar con Windows** (Configuración → Inicio): se abre solo al encender el equipo, minimizado junto al reloj.
- Permisos del menú de mesa leídos de la Configuración de SoftRestaurant: `configuracion.comanderoimprimir`,
  `comanderopagar` y `seguridaddividircuentas` (+ perfil del mesero si tiene). Nueva opción «Cuentas por separado».
- Imprimir, dividir y cobrar siguen pendientes hasta grabar la traza de esas operaciones en SoftRestaurant.

## Novedades 0.2.4

- Diseño nuevo con los colores del ícono: encabezado en degradado azul marino → azul rey → azul Windows, franja de acento,
  botón principal en degradado, tarjetas con sombra suave; modo día (plata) y noche (marino).
- APK con la paleta del ícono del Comandero: naranja vivo, ámbar, azul marino y verde «enviado».

## Novedades 0.2.3

- Ícono nuevo de Enlace Móvil (ejecutable, ventana y bandeja) y del Comandero (APK).
- Bienvenida animada al abrir: el ícono entra con rebote y aparece el nombre (clic para saltarla).

## Novedades 0.2.2

- Panel: estado con círculo de color (verde conectado, rojo desconectado, gris revocado); botones **Eliminar** y **Eliminar revocados**.
- **Segundo plano**: al minimizar, Enlace Móvil se oculta junto al reloj y sigue atendiendo; doble clic en el ícono lo abre, clic derecho → Salir.
- Menú de mesa en la APK: `GET /mesas/{folio}` (consultar cuenta) y `GET /mesas/opciones` (permisos del mesero según su perfil de SR).
- Envío inmediato: el respaldo del día se hace al arrancar (ya no retrasa la primera comanda) y cada comanda avisa al instante
  a todas las APK (`mesa.cambio`) para refrescar Mesas.
- Corregido: Enlace no abría por el orden de inicialización del actualizador.

## Novedades 0.2.1 — Envío de comandas a SoftRestaurant

- **Enviar comanda** (APK → Enlace → SR): si la mesa no tiene cuenta abierta la abre, y agrega los productos con sus
  modificadores y notas. Escribe exactamente lo mismo que el Comandero de SoftRestaurant (traza de la Fase 0):
  `tempcheques`, `tempcheqdet`, `cuentas`, `detallescuentas`, `folios` (orden y folio de producción) y los totales en claro.
  Todo en una sola transacción; el `opId` queda en `detallescuentas.id_unico`, así un reintento nunca duplica.
- **Precios del lado del servidor**: la APK no manda precios; se usan los del catálogo vigente y los impuestos de `productosdetalle`.
- **Seguridad de arranque**: por omisión solo se permite la mesa **PRUEBA** (Configuración → «Mesas permitidas»; vacío = todas).
- **Respaldo automático** `COPY_ONLY` + `RESTORE VERIFYONLY` antes de la primera comanda del día
  (carpeta `C:\Users\Public\Documents\EnlaceMovil\Respaldos`; si SQL no puede escribir ahí, usa su carpeta predeterminada).
- Rechazos claros para el mesero: cuenta ya impresa, mesa abierta en una pantalla de SR, cuenta con descuento o pagos,
  producto bloqueado, mesero inexistente en SR.
- **No imprime la comanda en cocina/barra**: SoftRestaurant la imprime desde su propio programa al capturar; desde Enlace queda
  pendiente (en esta base de pruebas las áreas no tienen impresora configurada).
- Si se conecta con el usuario `enlace_movil`, ejecutar `sql\02_permisos_comandas.sql`.
- Pruebas: 61 automáticas (16 nuevas contra una copia real de la base, de punta a punta por HTTPS).


## Novedades 0.2.0

- **Detectar SoftRestaurant** (Configuración): encuentra la instancia SQL, la base y la empresa y llena las dos cadenas (usuario de Windows).
- **Meseros desde SoftRestaurant** (solo lectura): en la APK entran con la misma contraseña del Comandero de SR.
- **Conexión automática**: la APK encuentra Enlace Móvil por la Wi-Fi (UDP 8788) y se conecta con «Conectar», sin QR ni código.
  Se puede apagar en Configuración (entonces se usa el QR). Un teléfono revocado no puede reconectarse solo.
- **Mesas**: la APK ve las cuentas abiertas de SoftRestaurant (área, mesa, mesero, total). Solo lectura.
- Colores azul rey, gris y negro con **modo día y noche**; pie «Desarrollado por SoftGala · versión».
- **Actualizar versión** (abajo a la derecha): revisa GitHub Releases (`xavisystem4-lab/comandero-softgala-releases`), avisa si hay
  versión nueva, descarga con progreso y reinstala conservando la configuración.
- Reglas de firewall: TCP 8787 (API y enlace) y UDP 8788 (búsqueda automática), solo redes privadas.


Servidor local en Windows que enlaza **SoftRestaurant 11** con la APK **Comandero Móvil** de los meseros.
Versión 0.1.0: fases 1 a 5 del plan (base, API local, autenticación, enlace persistente, sincronización de
catálogo e idempotencia). **No escribe nada en SoftRestaurant**: la escritura de comandas espera la Fase 0
(esquema transaccional + traza).

## Qué hace hoy

| Función | Estado |
| --- | --- |
| Catálogo real (grupos, subgrupos, productos, precio vigente, modificadores, área) desde SQL o desde la exportación XML | Listo |
| Verificación del esquema de SoftRestaurant al arrancar (si cambia, no lee) | Listo |
| API local HTTPS con certificado autofirmado anclado por la APK | Listo |
| Emparejamiento por QR de un solo uso (5 min), revocación de dispositivos | Listo |
| Login de mesero con PIN (PBKDF2), bloqueo tras 5 intentos, token por dispositivo | Listo |
| Enlace persistente SignalR: `link.status` cada 5 s, ping, corte por inactividad (20 s) | Listo |
| Aviso de cambio de catálogo a todas las APK | Listo |
| Operaciones idempotentes (`opId` + `Idempotency-Key`), sin duplicados en reintentos | Listo (operación de diagnóstico) |
| Panel WPF: estado, dispositivos, meseros, operaciones, errores, configuración, QR | Listo |
| Envío de comandas (abrir mesa + agregar productos) | Listo (0.2.1) |
| Cancelaciones, impresión de comanda, cobro | Pendiente |
| Meseros leídos de SoftRestaurant | **Pendiente Fase 0** (hoy se dan de alta en el panel) |
| Descubrimiento automático (mDNS) | Pendiente (hoy: QR con IP + huella) |

## Estructura

```
src/EnlaceMovil.Core            Modelos del catálogo verificado, precio vigente, protocolo (DTO, códigos de error)
src/EnlaceMovil.SoftRestaurant  Lectura SOLO de SELECT: SQL Server o exportación XML; verificador de esquema
src/EnlaceMovil.Data            Base propia "EnlaceMovil" (SQL Server) o memoria para pruebas
src/EnlaceMovil.Server          Kestrel HTTPS + SignalR, autenticación, procesador idempotente, monitores
src/EnlaceMovil.App             Panel WPF (Windows)
src/EnlaceMovil.Headless        Mismo servidor sin interfaz (consola / servicio)
tools/EnlaceMovil.Simulador     Simula N APK con el protocolo real (para probar sin teléfono)
tests/EnlaceMovil.Tests         41 pruebas: catálogo, precios, seguridad, idempotencia, integración, SQL Server
sql/01_usuario_enlace_movil.sql Login de mínimos privilegios
catalogo-demo/                  Exportación de catálogo DBS_MEDUSA (modo demo)
```

## Requisitos

- Windows 10/11 x64 con **.NET 8 Desktop Runtime** y **ASP.NET Core Runtime 8** (o el SDK de .NET 8, que trae ambos).
- SQL Server de SoftRestaurant en la misma PC.
- Red Wi-Fi marcada como **Privada** en Windows; IP de la PC reservada en el router.

## Puesta en marcha (modo demo, sin tocar SQL)

1. Abrir `EnlaceMovil.exe`. La primera vez abre **Configuración**.
2. Elegir «Exportación XML» → `catalogo-demo\DBS_MEDUSA_190926.ZIP`, almacén «Memoria» → **Guardar y reiniciar**.
3. Pestaña **Meseros**: dar de alta, p. ej. clave `01`, PIN `1234`.
4. **Crear regla de firewall** (pide permiso de administrador).
5. Probar sin teléfono: `EnlaceMovil.Simulador.exe --meseros 4 --mesero 01 --pin 1234 --segundos 60`.

## Puesta en marcha con SoftRestaurant (solo lectura)

1. Ejecutar `sql\01_usuario_enlace_movil.sql` (reemplazar contraseña y nombre de base).
2. En Configuración: «SQL Server de SoftRestaurant» + cadena con `enlace_movil`; **Probar conexión**
   (debe decir «Esquema de catálogo verificado»).
3. Base de Enlace: «SQL Server — EnlaceMovil» con la misma credencial.
4. **Guardar y reiniciar**. Las cadenas se guardan cifradas con DPAPI en `%ProgramData%\EnlaceMovil\config.json`.

## Archivos del servidor (`%ProgramData%\EnlaceMovil`)

| Archivo | Contenido |
| --- | --- |
| `config.json` | Configuración; cadenas de conexión cifradas (DPAPI, ámbito máquina) |
| `identidad.json` | ServerId fijo; llave de tokens y clave del certificado, cifradas |
| `servidor.pfx` | Certificado TLS autofirmado (10 años). Regenerarlo obliga a reemparejar todas las APK |
| `logs\enlace-AAAAMMDD.log` | Log técnico diario, 30 días |

## Compilar y probar

```powershell
dotnet build EnlaceMovil.sln -c Release
dotnet test tests/EnlaceMovil.Tests                     # sin SQL: las pruebas de SQL terminan sin hacer nada
$env:ENLACE_SQL="Server=.\SQLEXPRESS;User Id=sa;Password=...;TrustServerCertificate=true"
dotnet test tests/EnlaceMovil.Tests                     # con SQL de PRUEBAS (crea/borra bases *_Pruebas)
.\publicar.ps1                                          # genera publicar\ con los .exe
```

Nunca apunte `ENLACE_SQL` a la instancia de un cliente.

## Protocolo para la APK (resumen)

Base: `https://<ip>:8787/api/v1` · Hub: `wss://<ip>:8787/hub/enlace?access_token=<token>`

| Paso | Llamada |
| --- | --- |
| 1. Escanear QR | JSON `{v, serverId, nombre, hosts[], puerto, huellaSha256, codigo, expira}` |
| 2. Validar servidor | `GET /info` con certificado anclado a `huellaSha256` |
| 3. Emparejar | `POST /dispositivos/emparejar {codigo, nombreDispositivo, modelo, androidId}` → `{deviceId, deviceSecret}` (guardar en Keystore) |
| 4. Meseros | `GET /meseros` con encabezados `X-Device-Id`, `X-Device-Secret` |
| 5. Login | `POST /auth/login {deviceId, deviceSecret, meseroId, pin}` → `{token, expira, mesero, serverEpoch}` |
| 6. Catálogo | `GET /catalogo?version=<v>` → 200 con catálogo, o 304 si no cambió |
| 7. Enlace | Conectar al hub; recibir `link.status` cada 5 s; invocar `Ping(ticksUtc)` cada 5 s |
| 8. Operaciones | `POST` con `Idempotency-Key: <opId>` (= `opId` del cuerpo); reintentar SIEMPRE con el mismo `opId` |

**ENLACE ACTIVO** = hub conectado + `link.status` recibido hace ≤ 15 s + `sqlOk = true` + `serverId` y huella correctos.
Si `serverEpoch` cambia, el servidor se reinició: pedir estado completo.

Códigos de error estables (`{codigo, mensaje}`): `AUTH_EXPIRED` → pedir PIN · `DEVICE_REVOKED` → reemparejar ·
`AUTH_LOCKED` · `PAIRING_INVALID` · `VALIDATION` · `IN_PROGRESS` (409, consultar `GET /operaciones/{opId}`) ·
`IDEMPOTENCY_MISMATCH` · `SQL_UNAVAILABLE` · `RATE_LIMITED` · `INTERNAL` (reintentable).
